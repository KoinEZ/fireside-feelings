@echo off
rem Ru (Fireside Feelings) - Russian language installer. Double-click this file.
rem If Steam is installed somewhere unusual, pass the folder:
rem   install.bat "D:\Steam library\steamapps\common\FiresideFeelings"
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0install.ps1" %*
echo.
pause
