﻿# Включить или выключить переводчик сообщений, не открывая fireside_mt.cfg.
# Рядом с игрой лежат chat_off.bat / chat_on.bat. Игру после переключения надо перезапустить:
# конфигурацию она читает один раз за запуск.
#
# Логика одна: управляющих строк в файле бывает несколько (off и mt), поэтому сначала снимаем
# все, потом пишем ровно ту, которая нужна. Так повторный клик не множит дубли.
param([switch]$Vkluchit)
$ErrorActionPreference = 'Stop'
$Skript = $PSScriptRoot
if (-not $Skript) { $Skript = Split-Path -Parent $MyInvocation.MyCommand.Path }
$Cfg = Join-Path $Skript 'fireside_mt.cfg'
if (-not (Test-Path -LiteralPath $Cfg)) {
    Write-Host "Рядом с этим файлом нет fireside_mt.cfg: $Cfg"
    Write-Host 'Сначала запусти install.bat — он кладёт и конфиг, и эти переключатели.'
    exit 1
}
$Zapis = @(Get-Content -LiteralPath $Cfg -Encoding UTF8)
$Ostalos = @($Zapis | Where-Object { $_.Trim() -notmatch '^(off|mt)\s*=' })
# Если в файле прописан адрес своего переводчика, включение возвращает в начало цепочки его,
# а не анонимный Google: иначе один клик выключить-включить тихо терял личный путь.
$Tsепочка = 'mt = gtx,mymemory'
foreach ($s in $Ostalos) {
    if ($s.Trim() -match '^koinz_url\s*=\s*\S') { $Tsепочка = 'mt = koinz,gtx,mymemory'; break }
}
if ($Vkluchit) {
    $Novye = @($Tsепочка) + $Ostalos
    Write-Host 'Переводчик сообщений ВКЛЮЧЕН: блок реплик уходит к переводчику одним запросом.'
    Write-Host "Цепочка: $($Tsепочка.Substring(4))"
} else {
    $Novye = @('off = 1') + $Ostalos
    Write-Host 'Переводчик сообщений ВЫКЛЮЧЕН: чужие реплики остаются на языке оригинала,'
    Write-Host 'весь остальной текст игры — русский.'
}
[IO.File]::WriteAllLines($Cfg, $Novye, (New-Object Text.UTF8Encoding $false))
Write-Host "Файл: $Cfg"
Write-Host 'Перезапусти игру, чтобы она прочитала это.'
