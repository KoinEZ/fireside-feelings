@echo off
rem Chat translator ON (one request per block of lines).
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0chat_switch.ps1" -Vkluchit
pause
