﻿# Установка русского языка в Fireside Feelings (Steam appid 2990600).
# Находит игру, сохраняет копию чистого exe в backup\ и ставит русский текст.
# Ни версию, ни хэши файлов не проверяет: подходит для любой сборки игры.
param([string]$Katalog = '')
$ErrorActionPreference = 'Stop'

$KliuchPacka = '7668142F3ED337054E855159EB29497B19309B8F3730F9D95409103DB394C62B'
$SlotVPuti   = 'res://.godot/exported/133200997/export-07bfdbd7ede18b7254501e89decd5ea2-En_Localisation_Data.res'

$Skript = $PSScriptRoot
if (-not $Skript) { $Skript = Split-Path -Parent $MyInvocation.MyCommand.Path }
$Gdre   = Join-Path $Skript 'gdre_tools.exe'
$Paki   = Join-Path $Skript 'patch'
$Rezerw = Join-Path $Skript 'backup'
$Log    = Join-Path $Skript 'gdre_install.log'

function Napis([string]$t) { Write-Host $t }

function NajtiIgru([string]$ukazano) {
    $kandidaty = @()
    if ($ukazano -ne '') { $kandidaty += $ukazano }
    foreach ($v in @('HKCU:\Software\Valve\Steam\Apps\2990600', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam\Apps\2990600')) {
        $o = Get-ItemProperty -Path $v -ErrorAction SilentlyContinue
        if ($o -and $o.InstallPath) { $kandidaty += (Join-Path $o.InstallPath 'FiresideFeelings') }
    }
    $Steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $Steam) { $Steam = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction SilentlyContinue).InstallPath }
    if ($Steam) {
        $kandidaty += (Join-Path $Steam 'steamapps\common\FiresideFeelings')
        $Vdf = Join-Path $Steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $Vdf) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $Vdf -Raw), '"path"\s+"([^"]+)"')) {
                $bibl = $m.Groups[1].Value -replace '\\\\', '\'
                $kandidaty += (Join-Path $bibl 'steamapps\common\FiresideFeelings')
            }
        }
    }
    foreach ($k in $kandidaty) {
        if ($k -and (Test-Path -LiteralPath (Join-Path $k 'FiresideFeelings.exe'))) { return $k }
    }
    return ''
}

function VybratPapku {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $okno = New-Object System.Windows.Forms.FolderBrowserDialog
        $okno.Description = 'Укажи папку, где лежит FiresideFeelings.exe'
        $okno.ShowNewFolderButton = $false
        if ($okno.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $okno.SelectedPath }
    } catch {}
    return ''
}

Napis 'Установка русского языка — Fireside Feelings'
Napis '---------------------------------------------'

$NET = @()
if (-not (Test-Path -LiteralPath $Gdre)) { $NET += 'gdre_tools.exe' }
if (-not (Test-Path -LiteralPath (Join-Path $Skript 'gdre_tools.pck'))) { $NET += 'gdre_tools.pck' }
if (-not (Test-Path -LiteralPath $Paki)) { $NET += 'папка patch' }
if (-not (Test-Path -LiteralPath (Join-Path $Paki 'localisation'))) { $NET += 'папка patch\localisation' }
if (-not (Test-Path -LiteralPath (Join-Path $Paki 'imported'))) { $NET += 'папка patch\imported' }
if ($NET.Count -gt 0) {
    Napis ('Не найдено: ' + ($NET -join ', ') + '.')
    Napis 'Распакуйте архив целиком и запускайте install.bat из папки FiresideFeelings_ru.'
    exit 1
}

$Igra = NajtiIgru $Katalog
if (-not $Igra) {
    Napis 'Не нашёл папку игры сам — выберите её в открывшемся окне.'
    $vybor = VybratPapku
    if ($vybor -ne '' -and (Test-Path -LiteralPath (Join-Path $vybor 'FiresideFeelings.exe'))) { $Igra = $vybor }
}
if (-not $Igra) {
    Napis 'Папку не нашли. Впишите путь к ней текстом, пустая строка — выход.'
    Napis 'Обычно это C:\Program Files (x86)\Steam\steamapps\common\FiresideFeelings'
    $ruk = (Read-Host 'Папка игры').Trim('"').Trim()
    if ($ruk -ne '' -and (Test-Path -LiteralPath (Join-Path $ruk 'FiresideFeelings.exe'))) { $Igra = $ruk }
}
if (-not $Igra) {
    Napis 'Игра не найдена, ничего не меняю.'
    Napis 'Можно указать путь сразу: install.bat "D:\Steam library\steamapps\common\FiresideFeelings"'
    exit 2
}
$Exe = Join-Path $Igra 'FiresideFeelings.exe'
Napis "Игра: $Exe"

if (Get-Process -Name 'FiresideFeelings' -ErrorAction SilentlyContinue) {
    Napis 'Игра запущена. Закройте её и запустите install.bat снова.'
    exit 3
}

New-Item -ItemType Directory -Force -Path $Rezerw | Out-Null
$Kopiya = Join-Path $Rezerw 'FiresideFeelings.exe.orig'
if (Test-Path -LiteralPath $Kopiya) {
    Napis 'Копия чистого файла уже есть, оставляю её.'
} else {
    Napis 'Сохраняю копию файла игры в backup\ ...'
    Copy-Item -LiteralPath $Exe -Destination $Kopiya
}

$PatchFile = @()
foreach ($f in (Get-ChildItem -LiteralPath (Join-Path $Paki 'localisation') -Filter '*.res')) {
    $PatchFile += "--patch-file=$($f.FullName)=res://Assets/Localisation/$($f.BaseName).en.translation"
}
$Slot = Join-Path $Paki 'Ru_Localisation_Data.res'
if (-not (Test-Path -LiteralPath $Slot)) { Napis 'В архиве нет файла patch\Ru_Localisation_Data.res — распакуйте архив заново.'; exit 4 }
$PatchFile += "--patch-file=$Slot=$SlotVPuti"
foreach ($f in (Get-ChildItem -LiteralPath (Join-Path $Paki 'imported') -Filter '*.ctex')) {
    $PatchFile += "--patch-file=$($f.FullName)=res://.godot/imported/$($f.Name)"
}
$Gdc = Join-Path $Paki 'Database_Manager.gdc'
if (Test-Path -LiteralPath $Gdc) { $PatchFile += "--patch-file=$Gdc=res://Scripts/DataBase/Database_Manager.gdc" }

# 168 имён вопросов длинные; локальные копии с короткими именами укладывают
# аргументы в предел командной строки Windows. Патч идёт партиями по 80 файлов.
$Questions = Join-Path $Paki 'questions'
$QuestionPatch = @()
$QStage = Join-Path $env:SystemDrive 'Temp\fireside_ru_q'
try { New-Item -ItemType Directory -Force -Path $QStage | Out-Null }
catch { $QStage = Join-Path $env:TEMP 'fireside_ru_q'; New-Item -ItemType Directory -Force -Path $QStage | Out-Null }
Get-ChildItem -LiteralPath $QStage -File -ErrorAction SilentlyContinue | Remove-Item -Force
if (Test-Path -LiteralPath $Questions) {
    $i = 0
    foreach ($f in (Get-ChildItem -LiteralPath $Questions -Filter '*.res' | Sort-Object Name)) {
        $short = Join-Path $QStage ('q{0:D3}.res' -f $i)
        Copy-Item -LiteralPath $f.FullName -Destination $short -Force
        $QuestionPatch += "--patch-file=$short=res://.godot/exported/133200997/$($f.Name)"
        $i++
    }
}

$Novy = Join-Path $Skript 'novyj_exe.tmp'
if (Test-Path -LiteralPath $Novy) { Remove-Item -LiteralPath $Novy -Force }
if (Test-Path -LiteralPath $Log) { Remove-Item -LiteralPath $Log -Force }
Napis 'Собираю русский файл игры — несколько минут, окно можно не трогать.'

$Parts = New-Object System.Collections.ArrayList
if ($QuestionPatch.Count -le 80) {
    [void]$Parts.Add(@($PatchFile + $QuestionPatch))
} else {
    [void]$Parts.Add(@($PatchFile + $QuestionPatch[0..79]))
    $pos = 80
    while ($pos -lt $QuestionPatch.Count) {
        $end = [Math]::Min($pos + 79, $QuestionPatch.Count - 1)
        [void]$Parts.Add(@($QuestionPatch[$pos..$end]))
        $pos += 80
    }
}

$Vhod = $Exe
$No = 0
$Oshibka = $false
foreach ($part in $Parts) {
    $No++
    $Out = if ($No -eq $Parts.Count) { $Novy } else { Join-Path $Skript ("novyj_exe_$No.tmp") }
    if (Test-Path -LiteralPath $Out) { Remove-Item -LiteralPath $Out -Force }
    & $Gdre --headless "--pck-patch=$Vhod" "--key=$KliuchPacka" $part "--embed=$Exe" "--output=$Out" 2>&1 |
        Out-File -LiteralPath $Log -Encoding UTF8 -Append
    if (-not (Test-Path -LiteralPath $Out)) { $Oshibka = $true; break }
    if ($Vhod -ne $Exe) { Remove-Item -LiteralPath $Vhod -Force -ErrorAction SilentlyContinue }
    $Vhod = $Out
}
Get-ChildItem -LiteralPath $QStage -File -ErrorAction SilentlyContinue | Remove-Item -Force
Get-ChildItem -LiteralPath $Skript -Filter 'novyj_exe_*.tmp' -ErrorAction SilentlyContinue | Remove-Item -Force

if ($Oshibka -or -not (Test-Path -LiteralPath $Novy)) {
    if (Test-Path -LiteralPath $Novy) { Remove-Item -LiteralPath $Novy -Force }
    Napis 'Сборка не удалась. Игра не тронута, чистый файл лежит в backup\.'
    Napis 'Подробности — в gdre_install.log.'
    exit 5
}

Copy-Item -LiteralPath $Novy -Destination $Exe -Force
Remove-Item -LiteralPath $Novy -Force

$Cfg = Join-Path $Igra 'fireside_mt.cfg'
$Shablon = Join-Path $Skript 'fireside_mt.cfg'
if (-not (Test-Path -LiteralPath $Cfg) -and (Test-Path -LiteralPath $Shablon)) {
    Copy-Item -LiteralPath $Shablon -Destination $Cfg
}
foreach ($f in ('chat_off.bat', 'chat_on.bat', 'chat_switch.ps1')) {
    $istochnik = Join-Path $Skript $f
    if (Test-Path -LiteralPath $istochnik) { Copy-Item -LiteralPath $istochnik -Destination (Join-Path $Igra $f) -Force }
}

Napis '---------------------------------------------'
Napis 'Готово. Игра на русском.'
Napis 'Если язык не включился сам: Настройки -> Язык -> Русский.'
Napis 'Перевод сообщений выключается файлом chat_off.bat рядом с игрой.'
Napis 'Вернуть как было — uninstall.bat.'
exit 0
