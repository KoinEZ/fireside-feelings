@echo off
rem Chat translator OFF. Interface and game text stay Russian.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0chat_switch.ps1"
pause
