﻿# Возврат игры к чистому файлу из backup\. Ничего не проверяет и не сравнивает.
param([string]$Katalog = '')
$ErrorActionPreference = 'Stop'

$Skript = Split-Path -Parent $MyInvocation.MyCommand.Path
$Kopiya = Join-Path $Skript 'backup\FiresideFeelings.exe.orig'

function Napis([string]$t) { Write-Host $t }

function NajtiIgru([string]$ukazano) {
    $kandidaty = @()
    if ($ukazano -ne '') { $kandidaty += $ukazano }
    foreach ($v in @('HKCU:\Software\Valve\Steam\Apps\2990600', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam\Apps\2990600')) {
        $o = Get-ItemProperty -Path $v -ErrorAction SilentlyContinue
        if ($o -and $o.InstallPath) { $kandidaty += (Join-Path $o.InstallPath 'FiresideFeelings') }
    }
    $Steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $Steam) { $Steam = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction SilentlyContinue).InstallPath }
    if ($Steam) {
        $kandidaty += (Join-Path $Steam 'steamapps\common\FiresideFeelings')
        $Vdf = Join-Path $Steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $Vdf) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $Vdf -Raw), '"path"\s+"([^"]+)"')) {
                $bibl = $m.Groups[1].Value -replace '\\\\', '\'
                $kandidaty += (Join-Path $bibl 'steamapps\common\FiresideFeelings')
            }
        }
    }
    foreach ($k in $kandidaty) {
        if ($k -and (Test-Path -LiteralPath (Join-Path $k 'FiresideFeelings.exe'))) { return $k }
    }
    return ''
}

Napis 'Возврат Fireside Feelings к чистому файлу'
Napis '------------------------------------------'

$Igra = NajtiIgru $Katalog
if (-not $Igra) {
    Napis 'Папка игры не найдена. Укажите её так:'
    Napis '  uninstall.bat "D:\Steam library\steamapps\common\FiresideFeelings"'
    exit 2
}
$Exe = Join-Path $Igra 'FiresideFeelings.exe'
Napis "Игра: $Exe"

if (Get-Process -Name 'FiresideFeelings' -ErrorAction SilentlyContinue) {
    Napis 'Игра запущена. Закройте её и повторите.'
    exit 3
}

if (-not (Test-Path -LiteralPath $Kopiya)) {
    Napis 'Резервной копии в backup\ нет — возвращать нечего.'
    Napis 'В Steam: свойства игры -> Установленные файлы -> Проверить целостность файлов игры.'
    exit 4
}

Copy-Item -LiteralPath $Kopiya -Destination $Exe -Force
Napis '---------------------------------------------'
Napis 'Готово, файл игры вернулся к исходному.'
Napis 'fireside_mt.cfg и переключатели chat_on/chat_off оставлены: без русика игра их не читает.'
Napis 'Поставить снова — install.bat.'
exit 0
